using UnityEngine;

public class SinglePlayerMovement : MonoBehaviour
{
    //private InputSystem_Actions _controls;
    //private float _turnSpeed=80;
    //private float _moveSpeed=3;

    //void Start()
    //{
    //    //_controls = new InputSystem_Actions();
    //    //_controls.Enable();
    //}


    //void Update()
    //{
    //    //float h = _controls.Player.Move.ReadValue<Vector2>().x;
    //    //float v = _controls.Player.Move.ReadValue<Vector2>().y;
    //    //transform.rotation *= Quaternion.AngleAxis(h*_turnSpeed*Time.deltaTime, Vector3.up);
    //    //transform.position += v * _moveSpeed * Time.deltaTime*transform.forward;
    //}
}
